package com.hotwire.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hotwire.base.Page;
import com.hotwire.utilities.TestUtils;

public class PackagesPage extends Page {

	@FindBy(css = "button[data-bdd='farefinder-package-bundleoption-car']")
	WebElement carBtn;

	@FindBy(css = "button[data-bdd='farefinder-package-bundleoption-hotel']")
	WebElement hotelBtn;

	@FindBy(css = "button[data-bdd='farefinder-package-bundleoption-flight']")
	WebElement flightBtn;

	@FindBy(xpath = "//input[@id='farefinder-package-origin-location-input']")
	WebElement flyFromBtn; // click down

	@FindBy(xpath = "//input[@id='farefinder-package-destination-location-input']")
	WebElement flyToBtn;

	@FindBy(xpath = "//input[@id='farefinder-package-destination-location-input']")
	WebElement depatingCal;

	@FindBy(xpath = "//select[@id='farefinder-package-pickuptime-input']")
	WebElement morningVal;

	@FindBy(xpath = "//input[@id='farefinder-package-enddate-input']")
	WebElement returningCal;

	@FindBy(xpath = "//select[@id='farefinder-package-dropofftime-input']")
	WebElement eveningVal;

	@FindBy(xpath = "//button[@id='farefinder-package-search-button']")
	WebElement findADealBtn;

	public PackagesPage() {
		PageFactory.initElements(driver, this);
	}

	public String verifyUrl() {
		return driver.getCurrentUrl();
	}

	public String findADeal() {

		if (verifyUrl().equalsIgnoreCase("https://www.hotwire.com/packages/")) {

			if (flightBtn.isDisplayed() && hotelBtn.isDisplayed() && carBtn.isDisplayed()) {
				if (!flightBtn.isEnabled()) {
					flightBtn.click();
				}
				if (!hotelBtn.isEnabled()) {
					hotelBtn.click();
				}
				if (!carBtn.isEnabled()) {
					carBtn.click();
				}
			}

			flyFromBtn.sendKeys("SFO",Keys.ARROW_DOWN,Keys.ENTER);
			flyToBtn.sendKeys("LAX",Keys.ARROW_DOWN,Keys.ENTER);
			
			String nextDate = TestUtils.getNextDate();
			String returnDate = TestUtils.getretunDate(21);
			
			depatingCal.sendKeys(nextDate);
			TestUtils.selection(morningVal, "Morning");
			
			returningCal.sendKeys(returnDate);
			TestUtils.selection(eveningVal, "Evening");
			
			findADealBtn.submit();
			
			
			if(driver.findElement(By.cssSelector(".h-15607-travelAd"))!=null) {
				return "Result found";
			}

		}
		return null;

	}

}
