package com.hotwire.pages;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hotwire.base.Page;

public class HomePage extends Page {
	@FindBy(xpath = "//ul[@class='nav nav-pills']//a[.='Vacations']")
	@CacheLookup
	WebElement vacationsBtn;

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	public String verifyUrl() {
		return driver.getCurrentUrl();
	}

	public PackagesPage clickVacations() {

		if (verifyUrl().equalsIgnoreCase("https://www.hotwire.com/")) {
			try {
				vacationsBtn.click();
				return new PackagesPage();
			} catch (NoSuchElementException e) {
				e.printStackTrace();
				return null;
			}
		}
		return null;
	}
}
