package com.hotwire.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class TestUtils {
		
	
	public static String getNextDate(){
		  SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		  Calendar calendar = Calendar.getInstance();
		  Date date = calendar.getTime();
		  calendar.setTime(date);
		  calendar.add(Calendar.DAY_OF_YEAR, 1);
		  return format.format(calendar.getTime()); 
		}
	
	public static String getretunDate(int n) {
		  SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		  Calendar calendar = Calendar.getInstance();
		  Date date = calendar.getTime();
		  calendar.setTime(date);
		  calendar.add(Calendar.DAY_OF_YEAR, n);
		  return format.format(calendar.getTime());
		
	}
	
	public static void selection(WebElement objectKey, String data) {
		Select s = new Select(objectKey);
		s.selectByVisibleText(data);
	}
}
