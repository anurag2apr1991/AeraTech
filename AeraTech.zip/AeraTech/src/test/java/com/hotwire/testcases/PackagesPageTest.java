package com.hotwire.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hotwire.base.Page;
import com.hotwire.pages.HomePage;
import com.hotwire.pages.PackagesPage;

public class PackagesPageTest extends Page{
	
	HomePage homePage;
	PackagesPage packagePage;
	
	public PackagesPageTest() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		
		initialization();
		homePage = new HomePage();
		packagePage = homePage.clickVacations();
		
	}
	
	@Test(priority=1)
	public void VerifyUrl() {
		Assert.assertEquals(packagePage.verifyUrl(),"https://www.hotwire.com/packages/");
	}
	
	@Test(priority=2)
	public void VerifyFindADeal() {
		String dealFound = packagePage.findADeal();
		Assert.assertEquals(dealFound, "Result found");
	}
	
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
