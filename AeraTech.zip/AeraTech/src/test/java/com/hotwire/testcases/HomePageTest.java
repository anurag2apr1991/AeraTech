package com.hotwire.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hotwire.base.Page;
import com.hotwire.pages.HomePage;
import com.hotwire.pages.PackagesPage;

public class HomePageTest extends Page{
	HomePage homePage;
	PackagesPage packagePage;
	
	public HomePageTest() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		packagePage = new PackagesPage();
		homePage = new HomePage();
	}
	
	@Test(priority=1)
	public void VerifyUrl() {
		Assert.assertEquals(homePage.verifyUrl(),"https://www.hotwire.com/");
		
	}
	
	@Test(priority=2)
	public void verifyContactsLinkTest() {
		packagePage = homePage.clickVacations();
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}

}
